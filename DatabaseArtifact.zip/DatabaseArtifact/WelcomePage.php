<?php


//create menu of options for database
 if ($_POST['submit'])
 {
   if($_POST['menuOption'] == "insertPerson")
   {
	 header("Location: http://127.0.0.1/Insert.php");
   }
   else if($_POST['menuOption'] == "displayPerson")
   {
	 header("Location: http://127.0.0.1/Display.php");
   }
   else if($_POST['menuOption'] == "addPerson")
   {
       header("Location: http://127.0.0.1/AddColumnToPerson.php");
   }
   else if($_POST['menuOption'] == "removePerson")
   {
       header("Location: http://127.0.0.1/RemoveColumnFromPerson.php");
   }
   else if($_POST['menuOption'] == "addContactList")
   {
     header("Location: http://127.0.0.1/AddColumnToContactList.php");
   }
   else if($_POST['menuOption'] == "removeContactList")
   {
     header("Location: http://127.0.0.1/RemoveColumnFromContactList.php");
   }
 }
 
?>
<!-- Code for allowing only one option to be chosen from menu -->

<html>
<head> 
<title>Welcome Page</title>
</head>
<body>

<H1><font color=blue>Menu Options</font><H1>
<form method =post action="WelcomePage.php">
<input type=radio name=menuOption value="displayPerson">Display/Modify Person Table
<BR>
<input type=radio name=menuOption value="insertPerson">Insert Into Person Table
<BR>
<input type=radio name=menuOption value="addPerson">Add Column To Person Table
<BR>
<input type=radio name=menuOption value="removePerson">Remove Column From Person Table
<BR>
<input type=radio name=menuOption value="addContactList">Add Column To Contact List Table
<BR>
<input type=radio name=menuOption value="removeContactList">Remove Column From Contact List Table
<BR>
<input type=submit name=submit value="Submit">

</body>
</html>
