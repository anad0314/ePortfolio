<html>
<head>
<title>Display / Modify Person Table</title>
</head>
<body>
<H1><font color=blue>Display Person Table</font></H1>
<?php    
    include '_config.php';
    
    $link = mysqli_connect($server, $user, $password, $database);
    
    if (!$link)
    {
        die('Could not connect: ' . mysqli_connect_error());
    }

      // Build SQL Query  to display person table
      $sql = "SELECT * FROM person";

      if($result = mysqli_query($link, $sql))
      {
          // Code to display whole table dynamically
          $fields_num = mysqli_num_fields($result);
          
          echo "<table border='1'><tr>";
          // printing table headers
          for($i = 0; $i < $fields_num; $i++)
          {
              $field = mysqli_fetch_field($result);
              echo "<td>{$field->name}</td>";
          }
          echo "</tr>\n";
          // printing table rows
          while($row = mysqli_fetch_row($result))
          {
              echo "<tr>";
              
              // $row is array... foreach( .. ) puts every element
              // of $row to $cell variable
              foreach($row as $cell)
                  echo "<td>$cell</td>";
                  
                  echo "</tr>\n";
          } 
          echo "</table>";
      }
   
  mysqli_close($link);
  
?>    
    

<H1><font color=blue>Modify Person Table</font></H1>
  
<form method=post action="Display.php">

<table border=1>
<tr><td>
<form method="post" action="Delete.php">
ID To Delete: <input type="text" name="deleteID"><br>
<input type="submit" name="submitDelete" value="Delete">
</form>
</td></tr>
</table>

<table border=1>
<tr><td>
<form method="post" action="Insert.php">
ID To Update: <input type="text" name="updateID"><br>

<?php 

$fieldNames = array();
$i = 0;

include '_config.php';

$link = mysqli_connect($server, $user, $password, $database);

if (!$link)
{
    die('Could not connect: ' . mysqli_connect_error());
}

// Build SQL Query to modify person table
$sql = "SELECT * FROM person";

if($result = mysqli_query($link, $sql))
{
    while ($fieldInfo = mysqli_fetch_field($result))
    {
      $fieldNames[$i] = $fieldInfo->name;
      $i = $i + 1;
      
      if($i >= 2)
      {
          echo "$fieldInfo->name: <input type='text' name=$fieldInfo->name><br>";
      }
    }
}

?>
<input type="submit" name="submitUpdate" value="Update">
</form>
</table>

</form>
<form method="post" action="WelcomePage.php">
<input type="submit" value="Back to Welcome">
</form>
</body>
</html>



