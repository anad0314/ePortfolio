<html>
<head>
<title>Delete Person</title>
</head>
<body>

<?php

// Deleting a person from the table
if ($_POST['submitDelete'])
{
    include '_config.php';
    
    $link = mysqli_connect($server, $user, $password, $database);
    
    if (!$link)
    {
        die('Could not connect: ' . mysqli_connect_error());
    }
        
    // Build SQL Query  
    $sql = "DELETE FROM person WHERE person_id=('{$_POST['deleteID']}')";
        
    if($result = mysqli_query($link, $sql))
    {
        echo "Success Removing Person From Table";
        echo "<br>";
    }
    else
    {
        echo "Failure Removing Person From Table";
        echo "<br>";
    }
    
    //buttons needed to return
    
    echo '<form method="post" action="Display.php">';
    echo '<input type="submit" value="Back to List">';
    echo '</form>';
}

mysqli_close($link);

?>

</body>
</html>
