<?php

include '_config.php';

$link = mysqli_connect($server, $user, $password, $database);

if (!$link)
{
    die('Could not connect: ' . mysqli_connect_error());
}

if ($_POST['submit'])
{
  // Build SQL Query to insert a person into the person table
  $sql = "insert into person (first_name, last_name) values ('{$_POST['first_name']}','{$_POST['last_name']}')";
  
  if($result = mysqli_query($link, $sql))
  {
    echo "Success Adding Person To Table";
    
    $sql = "SELECT * FROM person";
    
    if($result = mysqli_query($link, $sql))
    {
        // Code to display whole table dynamically
        $fields_num = mysqli_num_fields($result);
        
        echo "<h2>Updated Table Person</h2>";
        echo "<table border='1'><tr>";
        // printing table headers
        for($i = 0; $i < $fields_num; $i++)
        {
            $field = mysqli_fetch_field($result);
            echo "<td>{$field->name}</td>";
        }
        echo "</tr>\n";
        // printing table rows
        while($row = mysqli_fetch_row($result))
        {
            echo "<tr>";
            
            // $row is array... foreach( .. ) puts every element
            // of $row to $cell variable
            foreach($row as $cell)
                echo "<td>$cell</td>";
                
                echo "</tr>\n";
        }
        echo "<br>";
    }
    
  }
  else
  {
    echo "Failure Adding Person To Table";
  }
  
  //include buttons to return
  echo '<form method="post" action="WelcomePage.php">';
  echo '<input type="submit" value="Back to Welcome">';
  echo '</form>';
  
  mysql_close($link);
}
else if ($_POST['submitUpdate'])
{
    
    // Grab all the field names so we can get the button names
    $fieldNames = array();
    $i = 0;
        
    // Get all the field names for the person table and load them into an array
    $sql = "SELECT * FROM person";
    
    if($result = mysqli_query($link, $sql))
    {
        while ($fieldInfo = mysqli_fetch_field($result))
        {
            $fieldNames[$i] = $fieldInfo->name;
            $i = $i + 1;
        }
    }
    
    // Build the SQL, looping through the field names
    $sql = "UPDATE person SET "; 
          
    for($i = 1; $i < sizeOf($fieldNames); $i++)
    {
        $sql .= "$fieldNames[$i]='{$_POST[$fieldNames[$i]]}'";
        
        if($i != (sizeOf($fieldNames) - 1))
        {
            $sql .= ",";
        }
    }
    
    $sql .= "WHERE person_id='{$_POST['updateID']}'";
    
        
    echo $sql;
    
    
    if($result = mysqli_query($link, $sql))
    {
        echo "Success Updating Table";
    }
    else   
    {
        echo "Failure Updating Table";
    }
    
    //display updated table, include button to return
    echo '<form method="post" action="Display.php">';
    echo '<input type="submit" value="Back to List">';
    echo '</form>';
    
    mysql_close($link);    
}

?>

<!-- This is code for the form buttons on the webpage -->

<html>
<title>Insert or Update Person Table</title>

<body>

<form method=post action="Insert.php">

<H1><font color=blue>Insert/Update Person</font></H1>

<table border=1>
<tr><td>First Name:  </td><td><input type=text name=first_name></td></tr>
<tr><td>Last Name:   </td><td><input type=text name=last_name></td></tr>
<tr><td>&nbsp; </td><td><input type=submit name=submit value="Add / Update"></td></tr>
</table>
</form>
<form method="post" action="WelcomePage.php">
<input type="submit" value="Back to Welcome">
</form>
</body>
</html>


