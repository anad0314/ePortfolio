<?php

// database information that is needed and included in the other files

# BE SURE TO chmod a+r __config.php or the webserver won't be able to access
$server   = "localhost";
$user     = "root";          // mysql user name
$password = "June67Tem!";    // mysql password
$database = "messaging";        // name of mysql database


?>


