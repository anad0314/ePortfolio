<?php

include '_config.php';

$link = mysqli_connect($server, $user, $password, $database);

if (!$link)
{
    die('Could not connect: ' . mysqli_connect_error());
}

if ($_POST['submit'])
{
    // Build SQL Query to drop column from contact_list table
    $sql = "ALTER TABLE contact_list DROP COLUMN {$_POST['column_name']}";
        
    if($result = mysqli_query($link, $sql))
    {
        echo "Success Dropping Column From Contact List Table<br>";
        
        $sql = "SELECT * FROM contact_list";
        
        if($result = mysqli_query($link, $sql))
        {
            // Code to display whole table dynamically
            $fields_num = mysqli_num_fields($result);
            
            echo "<h2>Updated Table Contact List</h2>";
            echo "<table border='1'><tr>";
            // printing table headers
            for($i = 0; $i < $fields_num; $i++)
            {
                $field = mysqli_fetch_field($result);
                echo "<td>{$field->name}</td>";
            }
            echo "</tr>\n";
            // printing table rows
            while($row = mysqli_fetch_row($result))
            {
                echo "<tr>";
                
                // $row is array... foreach( .. ) puts every element
                // of $row to $cell variable
                foreach($row as $cell)
                    echo "<td>$cell</td>";
                    
                    echo "</tr>\n";
            }
            echo "<br>";
        }
    }
    else
    {
        echo "Failure Dropping Column From Contact List Table";
    }
    
    //include return buttons
    echo '<form method="post" action="WelcomePage.php">';
    echo '<input type="submit" value="Back to Welcome">';
    echo '</form>';
    
    
    mysql_close($link);
}
?>


<html>
<title>Drop Column from Contact List</title>

<body>

<?php 

include '_config.php';

$link = mysqli_connect($server, $user, $password, $database);

if (!$link)
{
    die('Could not connect: ' . mysqli_connect_error());
}
   
//display contact_list table
$sql = "SELECT * FROM contact_list";

if($result = mysqli_query($link, $sql))
{
    // Code to display whole table dynamically
    $fields_num = mysqli_num_fields($result);
    
    echo "<table border='1'><tr>";
    // printing table headers
    for($i = 0; $i < $fields_num; $i++)
    {
        $field = mysqli_fetch_field($result);
        echo "<td>{$field->name}</td>";
    }
    echo "</tr>\n";

    echo "</table>";
    echo "<br>";
}
?>

<!-- This is code for the form buttons on the webpage -->

<form method=post action="RemoveColumnFromContactList.php">

<H1><font color=blue>Drop Column From Contact List</font></H1>

<table border=1>
<tr><td>Column To Drop:  </td><td><input type=text name=column_name></td></tr>
<tr><td>&nbsp; </td><td><input type=submit name=submit value="Drop"></td></tr>
</table>
</form>
<form method="post" action="WelcomePage.php">
<input type="submit" value="Back to Welcome">
</form>
</body>
</html>
