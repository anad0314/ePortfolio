
package finalprojectit145;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

//create authorization class to get and set username and use MD5 hash method
public class Authorization {
        private String userName;
        private String passWord;
        
        
        public void setUserName(String nameOfUser){
            userName = nameOfUser;
			return;
        }
        
        public void setPassword(String passwordOfUser){
            passWord = passwordOfUser;
            return;
        }
		
	public String getUserName(){
            return userName;
        }
        
        public String getPassword(){
            return passWord;
        }
        //MD5 hash method taken from final project outline
        public String MD5hash(String original) throws NoSuchAlgorithmException{
               
            original = passWord;  //Replace "password" with the actual password inputted by the user
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(original.getBytes());
		byte[] digest = md.digest();
                
                StringBuffer sb = new StringBuffer();
		for (byte b : digest) {
			sb.append(String.format("%02x", b & 0xff));
                        
               
		}
        
        
        return sb.toString();
        }
}