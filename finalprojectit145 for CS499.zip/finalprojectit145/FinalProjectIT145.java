
package finalprojectit145;
import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class FinalProjectIT145 {
    
    public static void main(String[] args) throws Exception{
        //Call scanner and variables
        Scanner scnr = new Scanner(System.in);
        String userName = "";
        String passWord = "";
        int monitorOption = 0;
        int animalOption = 0;
        int habitatOption = 0;
        String enterButton = "";
        
        //initialize userAttempt
        int userAttempt = 0;        
          
        while (userAttempt < 3){
               userAttempt++;
                
                // ask user for username or option to quit
                System.out.print("Please enter username (or 'q' to exit): ");
                userName = scnr.nextLine();
                
                //send to method to setUserName
                Authorization user = new Authorization();
                user.setUserName(userName);
                System.out.print("");
                
                //create if statement if user hits 'q'
                if (userName.equals("q")){
                    break;
                }
                
                //ask for password and send to MD5 hash method
                System.out.print("Please enter password: ");
                passWord = scnr.nextLine();
                
                //send to method to setPassword
                user.setPassword(passWord);
                System.out.print("");
                
                String sb = user.MD5hash(passWord);
            
            
                //check credentials in credentials file
        
                File text = new File("src\\finalprojectit145\\credentials.txt");
                Scanner credential = new Scanner(text).useDelimiter("\t|\n");
                
                //create variables to parse through file
                String firstItem, secondItem, thirdItem, fourthItem;
                
                //create while loop to parse through text
                while(credential.hasNextLine()){
          
                    firstItem = credential.next();
                    secondItem = credential.next();
                    thirdItem = credential.next();
                    fourthItem = credential.next();
                    
                    //create if statement if the line in text matches username and MD5 hash password
                    if (secondItem.contains(sb) && firstItem.contains(userName)){
                        userAttempt = 0;
                        
                        //create if statements if match is good and parse appropiate file text for each role
                        
                        //if match is for zookeeper
                        if (fourthItem.contains("zookeeper")){
                            
                            File zootext = new File ("src\\finalprojectit145\\zookeeper.txt");
                            Scanner zookeeper = new Scanner (zootext);
                            String zooOutput;
                            
                            //print out information from zookeeper text
                            while(zookeeper.hasNextLine()){
                                zooOutput = zookeeper.nextLine();
                                System.out.print(zooOutput);
                                System.out.println();
                                
                            }                     
                            zookeeper.close();
                           
                            //ask zookeeper if they want to monitor an animal or a habitat or exit
                            System.out.println("\nWhat would you like to do next?");
                            System.out.println("1. Monitor an animal\n2. Monitor a habit\n3. Exit");
                            monitorOption = scnr.nextInt();
                           
                            while(monitorOption != 3){
                                
                                //situation to monitor an animal
                                if (monitorOption == 1){
                                    
                                    System.out.println("Choose one of the following:\n1. Details on lions\n2. Details on tigers\n3. Details on bears\n4. Details on giraffes\n5. Exit");
                                    animalOption = scnr.nextInt();
                                   
                                    while (animalOption != 5){
                                        
                                        //Details on lions
                                        if(animalOption == 1){
                                            
                                            File animaltext = new File ("src\\finalprojectit145\\animals.txt");
                                            Scanner animals = new Scanner (animaltext);
                                            String animalOutput;
                                            
                                            while(animals.hasNextLine()){
                                                
                                                animalOutput = animals.nextLine();
                                                
                                                if (animalOutput.equals("Animal - Lion")){
                                                    
                                                    for (int i = 0; i < 5; i++){
                                                        
                                                        if (animalOutput.contains("*")){
                                                            
                                                            String newAnimalOutput = animalOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newAnimalOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        
                                                        System.out.println(animalOutput);
                                                        animalOutput = animals.nextLine();
                                                    }
                                                }
                                            }
                                            animals.close();
                                            animalOption = 5;      
                                        }
                                        
                                        //Deatails on tigers
                                        else if (animalOption == 2){
                                            
                                            File animaltext = new File ("src\\finalprojectit145\\animals.txt");
                                            Scanner animals = new Scanner (animaltext);
                                            String animalOutput;
                                            
                                            while(animals.hasNextLine()){
                                                
                                                animalOutput = animals.nextLine();
                                                
                                                if (animalOutput.equals("Animal - Tiger")){
                                                    
                                                    for (int i = 0; i < 5; i++){
                                                        
                                                        if (animalOutput.contains("*")){
                                                            
                                                            String newAnimalOutput = animalOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newAnimalOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        System.out.println(animalOutput);
                                                        animalOutput = animals.nextLine();
                                                    }
                                                }
                                            }
                                            animals.close();
                                            animalOption = 5;      
                                        }
                                        
                                        //Details on bears
                                        else if (animalOption == 3){
                                            
                                            File animaltext = new File ("src\\finalprojectit145\\animals.txt");
                                            Scanner animals = new Scanner (animaltext);
                                            String animalOutput;
                                            
                                            while(animals.hasNextLine()){
                                                
                                                animalOutput = animals.nextLine();
                                                
                                                if (animalOutput.equals("Animal - Bear")){
                                                    
                                                    for (int i = 0; i < 5; i++){
                                                        
                                                        if (animalOutput.contains("*")){
                                                            
                                                            String newAnimalOutput = animalOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newAnimalOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        System.out.println(animalOutput);
                                                        animalOutput = animals.nextLine();
                                                    }
                                                } 
                                            }
                                            animals.close();
                                            animalOption = 5;      
                                        }
                                        
                                        //Details on giraffes
                                        else if (animalOption == 4){
                                            
                                            File animaltext = new File ("src\\finalprojectit145\\animals.txt");
                                            Scanner animals = new Scanner (animaltext);
                                            String animalOutput;
                                            
                                            while(animals.hasNextLine()){
                                                
                                                animalOutput = animals.nextLine();
                                                
                                                if (animalOutput.equals("Animal - Giraffe")){
                                                    
                                                    for (int i = 0; i < 5; i++){
                                                        
                                                        if (animalOutput.contains("*")){
                                                            
                                                            String newAnimalOutput = animalOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newAnimalOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        System.out.println(animalOutput);
                                                        
                                                        if (i < 4){
                                                            
                                                            animalOutput = animals.nextLine();
                                                        }
                                                    }
                                                }   
                                            }
                                            animals.close();
                                            animalOption = 5;        
                                        }
                                    }
                                    
                                    //go back to original menu for zookeeper
                                    System.out.println("1. Monitor an animal\n2. Monitor a habit\n3. Exit");
                                    monitorOption = scnr.nextInt();
                                    enterButton = scnr.nextLine();
                                }

                                //situation to monitor a habitat
                                if (monitorOption == 2){
                                    
                                    System.out.println("Choose one of the following:\n1. Details on penguin habitat\n2. Details on bird house\n3. Details on aquarium\n4. Exit");
                                    habitatOption = scnr.nextInt();
                                    
                                    while (habitatOption != 4){
                                        
                                        //Details on penguin habitat
                                        if(habitatOption == 1){
                                            
                                            File habitattext = new File ("src\\finalprojectit145\\habitats.txt");
                                            Scanner habitats = new Scanner (habitattext);
                                            String habitatOutput;
                                            
                                            while(habitats.hasNextLine()){
                                                
                                                habitatOutput = habitats.nextLine();
                                                
                                                if (habitatOutput.equals("Habitat - Penguin")){
                                                    
                                                    for (int i = 0; i < 4; i++){
                                                        
                                                        if (habitatOutput.contains("*")){
                                                            
                                                            String newHabitatOutput = habitatOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newHabitatOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        System.out.println(habitatOutput);
                                                        habitatOutput = habitats.nextLine();
                                                    }
                                                } 
                                            }
                                            habitats.close();
                                            habitatOption = 4;       
                                        }
                                        
                                        //Details on bird house
                                        else if(habitatOption == 2){
                                            
                                            File habitattext = new File ("src\\finalprojectit145\\habitats.txt");
                                            Scanner habitats = new Scanner (habitattext);
                                            String habitatOutput;
                                            
                                            while(habitats.hasNextLine()){
                                                
                                                habitatOutput = habitats.nextLine();
                                                
                                                if (habitatOutput.equals("Habitat - Bird")){
                                                    
                                                    for (int i = 0; i < 4; i++){
                                                        
                                                        if (habitatOutput.contains("*")){
                                                            
                                                            String newHabitatOutput = habitatOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newHabitatOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        System.out.println(habitatOutput);
                                                        habitatOutput = habitats.nextLine();
                                                    }
                                                }
                                            }
                                            habitats.close();
                                            habitatOption = 4;       
                                        }
                                        
                                        //Details on aquarium
                                        else if(habitatOption == 3){
                                            
                                            File habitattext = new File ("src\\finalprojectit145\\habitats.txt");
                                            Scanner habitats = new Scanner (habitattext);
                                            String habitatOutput;
                                            
                                            while(habitats.hasNextLine()){
                                                
                                                habitatOutput = habitats.nextLine();
                                                
                                                if (habitatOutput.equals("Habitat - Aquarium")){
                                                    
                                                    for (int i = 0; i < 4; i++){
                                                        
                                                        if (habitatOutput.contains("*")){
                                                            
                                                            String newHabitatOutput = habitatOutput.substring(5);
                                                            JOptionPane.showMessageDialog(null, newHabitatOutput, "ALERT", JOptionPane.WARNING_MESSAGE);
                                                        }
                                                        System.out.println(habitatOutput);
                                                        
                                                        if (i < 3){
                                                            
                                                            habitatOutput = habitats.nextLine();  
                                                    }
                                                } 
                                            }   
                                        }
                                            habitats.close();
                                            habitatOption = 4;
                                        
                                    }
                                        //print original menu for zookeeper
                                        System.out.println("1. Monitor an animal\n2. Monitor a habit\n3. Exit");
                                        monitorOption = scnr.nextInt();
                                        enterButton = scnr.nextLine();
                                }  
                            }
                        }  
                    }    
                        
                        //if match is for admin
                        else if (fourthItem.contains("admin")){
                            
                            File admintext = new File("src\\finalprojectit145\\admin.txt");
                            Scanner admin = new Scanner (admintext);
                            String adminOutput;
                            
                            while (admin.hasNextLine()){
                                
                                adminOutput = admin.nextLine();
                                System.out.print(adminOutput);
                                System.out.println();
                                
                            }
                            admin.close();
                            
                        }
                        
                        //if match is for veterinarian
                        else if (fourthItem.contains("veterinarian")){
                            
                            File vettext = new File("src\\finalprojectit145\\veterinarian.txt");
                            Scanner veterinarian = new Scanner (vettext);
                            String vetOutput;
                            
                            while (veterinarian.hasNextLine()){
                                
                                vetOutput = veterinarian.nextLine();
                                System.out.print(vetOutput);
                                System.out.println();
                                
                            }
                            veterinarian.close();
                        }
                    }
                }
                credential.close();
                
        }
       
        scnr.close();
        
        //create goodbye message if login attempts is 3
        if (userAttempt == 3){
            
            System.out.println("You have attempted three unsuccesful logins.  Goodbye.");
        }
    }
}
