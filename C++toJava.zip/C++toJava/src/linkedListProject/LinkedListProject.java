package linkedListProject;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedListProject {
	
	// define linked list globally
	static LinkedList<Bids> bidList;
	
	// define variable to hold unique ID
	String uniqueId = "";
	
	// function to display menu
	void display_menu() {
		System.out.println ( "Menu:\n1. Enter a Bid\n2. Display All Bids\n3. Find Bid\n4. Remove Bid\n5. Exit");
		System.out.print("Enter a choice: ");
	}
	
	// function to search for a bid based on ID
	static int Search() {
		Scanner findID = new Scanner(System.in);
    	
    	String find_Number = findID.next();
    	
    	// search through linked list to find bid ID and set equal to index otherwise say bid ID not found
    	int id_found = 0;
    	boolean bidkey = false;
    	for (int i = 0; i < bidList.size(); i++) {
    		     		
    		if (find_Number.equals(bidList.get(i).bidId)) {
    			bidkey = true;
    			id_found = i;
    		}		
    	}
    	
    	// notify the user that it wasn't found
    	if (bidkey == false) {
    		System.out.println("Bid ID not found");
    	}
    	
    	return id_found;
	}
	
	// function to search for a bid based on an argument passed in
	boolean SearchID(String ID) {
		Scanner findID = new Scanner(System.in);
		String id_found = ID;
    	boolean bidkey = false;
    	
    	for (int i = 0; i < bidList.size(); i++) {
    		     		
    		if (ID.equals(bidList.get(i).bidId)) {
    			System.out.println("ID already exits. Enter different ID: ");
    			id_found = findID.nextLine();
    			SearchID(id_found);	
    		}	
    	}
    	uniqueId = id_found;
    	return bidkey;
		
	}
	
	// function for menu to use cases
	void Menu() {
		Scanner choice = new Scanner(System.in);
		
		display_menu();
		int tempScanner = choice.nextInt();
		choice.nextLine();
		
		// while the user hasn't exited the program
		while (tempScanner != 5) {
			switch (tempScanner) {
			
				// case 1: ability to enter a bid into a linked list
		        case 1:
		        	Bids inputBids = new Bids();
		        	
		        	System.out.println("Enter bid ID: ");
		        	String ID = choice.nextLine();
		        	
		        	// call SearchID function to check for unique ID
		        	if (SearchID(ID) == false) {
		        		
		        		inputBids.bidId = uniqueId;
		        	}
		        	
		        	System.out.println("Enter bid title: ");
		        	inputBids.bidTitle = choice.nextLine();
		        	
		        	System.out.println("Enter bid amount (include $): ");
		        	inputBids.bidAmount = choice.nextLine();
		        	
		        	// while function to make sure user inputs $
		        	while (!inputBids.bidAmount.contains("$")) {
		        		System.out.println("Enter bid amount (include $ first): ");
			        	inputBids.bidAmount = choice.nextLine();
		        	}
		        	
		        	System.out.println("Enter bid fund: ");
		        	inputBids.bidFund= choice.nextLine();
		        	
		        	bidList.add(inputBids);
		        	
		        	// print out what was entered
		        	System.out.println(inputBids.bidId + " | " + inputBids.bidTitle + " | " + inputBids.bidAmount + " | " + inputBids.bidFund);
		        	
		        	
		        	display_menu();
		        	tempScanner = choice.nextInt();
		        	choice.nextLine();
		        
		            break;
	
		        // case 2: ability to display all bids in the linked list
		        case 2:
	
		        	// for loop for bidList
		        	for(int p = 0; p < bidList.size(); p++) {
		        		System.out.println(bidList.get(p).bidId + " | " + bidList.get(p).bidTitle + " | " + bidList.get(p).bidAmount + " | " + bidList.get(p).bidFund);
		        		
		        	}
		        	
		        	display_menu();
		        	tempScanner = choice.nextInt();
		        	choice.nextLine();
	
		            break;
		        
		        // case 3: ability to find a bid within the linked list
		        case 3:
		        	
		        	
		        	System.out.println("Enter Bid ID of item: ");
		        	int x = Search();		
		        	
		        	//print out bid as long as x does not equal zero
		        	if (x != 0) {
		        		System.out.println("Bid information: ");
		        		System.out.println(bidList.get(x).bidId + " | " + bidList.get(x).bidTitle + " | " + bidList.get(x).bidAmount + " | " + bidList.get(x).bidFund);
		        	}
		        	
		        	display_menu();
		        	tempScanner = choice.nextInt();
		        	choice.nextLine();
		        	
		            break;
	
		        // case 4: ability to remove a bid from the linked list
		        case 4:
		        	
		        	System.out.println("Enter Bid ID of item to be removed: ");
		        	int y = Search();
		        	
		        	System.out.println("Bid to be removed: ");
		        	System.out.println(bidList.get(y).bidId + " | " + bidList.get(y).bidTitle + " | " + bidList.get(y).bidAmount + " | " + bidList.get(y).bidFund);
		        			
		        	bidList.remove(y);
		        	System.out.println("Bid was removed");
		        	
		            display_menu();
		        	tempScanner = choice.nextInt();
		        	choice.nextLine();
		        	
		            break;
		            
		        default:
		        	 // Do nothing
		        	 break;
	        }
		}
		
		// close scanner before exiting program
		choice.close();
		System.out.println("Good Bye!");
	}

	// parser function to input csv file into a linked list
	void CSVParser() {

        String csvFile = "../src/linkedListProject/eBid_Monthly_Sales_Dec_2016.csv";
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] bid = line.split(cvsSplitBy);
                
                // assign to temporary Bids object then add to the bidList
                Bids holdingBid = new Bids();
                holdingBid.bidId = bid[1];
                holdingBid.bidTitle = bid[0];
                holdingBid.bidAmount = bid[4];
                holdingBid.bidFund = bid[8];
                
                bidList.add(holdingBid);
              
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	// Main function - program entry
	public static void main(String[] args) {
		
		// define linked list
		bidList = new LinkedList<Bids>();
		
		// load all bids initially into the linked list before calling menu
		LinkedListProject parser = new LinkedListProject();
		parser.CSVParser();
		
		// call menu function
		LinkedListProject menu = new LinkedListProject();
		menu.Menu(); 
	}
}


