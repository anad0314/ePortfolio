package linkedListProject;

public class Bids {
	
	String bidId;
	String bidTitle;
	String bidFund;
	String bidAmount;

}
